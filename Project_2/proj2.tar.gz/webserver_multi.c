#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include "webserver.h"

#define MAX_REQUEST 100

int request_buffer[MAX_REQUEST];
int buffer_in = 0;
int buffer_out = 0;

pthread_mutex_t lock;
sem_t sem_empty;
sem_t sem_full;

int port, numThread;

void *listener(void *arg)
{
    int r;
    struct sockaddr_in sin;
    struct sockaddr_in peer;
    socklen_t peer_len = sizeof(peer);
    int sock;

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Error creating listener socket");
        pthread_exit(NULL);
    }

    int optval = 1;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval));


    memset(&sin, 0, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = INADDR_ANY;
    sin.sin_port = htons(port);

    r = bind(sock, (struct sockaddr *) &sin, sizeof(sin));
    if(r < 0) {
        perror("Error binding socket:");
        close(sock);
        pthread_exit(NULL);
    }

    r = listen(sock, 10);
    if(r < 0) {
        perror("Error listening socket:");
        close(sock);
        pthread_exit(NULL);
    }

    printf("HTTP server listening on port %d\n", port);

    while (1)
    {
        int s;
        s = accept(sock, NULL, NULL);
        if (s < 0) {
            perror("Accept failed");

            continue;
        }


        sem_wait(&sem_empty);
        pthread_mutex_lock(&lock);

        request_buffer[buffer_in] = s;
        buffer_in = (buffer_in + 1) % MAX_REQUEST;

        pthread_mutex_unlock(&lock);
        sem_post(&sem_full);



    }

    close(sock);
    pthread_exit(NULL);
}

void *worker(void *arg) {
    int id = *((int*) arg);
    free(arg);
    printf("Worker thread %d started.\n", id);

    while (1) {
        int fd;


        sem_wait(&sem_full);
        pthread_mutex_lock(&lock);

        fd = request_buffer[buffer_out];
        buffer_out = (buffer_out + 1) % MAX_REQUEST;

        pthread_mutex_unlock(&lock);
        sem_post(&sem_empty);


        process(fd);

    }
    pthread_exit(NULL);
}




int main(int argc, char *argv[])
{
    if(argc != 3 || atoi(argv[1]) < 2000 || atoi(argv[1]) > 50000 || atoi(argv[2]) <= 0)
    {
        fprintf(stderr, "Usage: ./webserver_multi PORT(2001 ~ 49999) #_of_threads(>0)\n");
        return 0;
    }

    port = atoi(argv[1]);
    numThread = atoi(argv[2]);

    if (numThread > MAX_REQUEST) {
         fprintf(stderr, "Warning: Number of threads (%d) is greater than buffer size (%d).\n", numThread, MAX_REQUEST);

    }



    if (pthread_mutex_init(&lock, NULL) != 0) {
        perror("Mutex initialization failed");
        return 1;
    }
    if (sem_init(&sem_empty, 0, MAX_REQUEST) != 0) {
        perror("Empty semaphore initialization failed");
        pthread_mutex_destroy(&lock);
        return 1;
    }
    if (sem_init(&sem_full, 0, 0) != 0) {
        perror("Full semaphore initialization failed");
        sem_destroy(&sem_empty);
        pthread_mutex_destroy(&lock);
        return 1;
    }



    pthread_t listener_tid;
    pthread_t worker_tids[numThread];


    if (pthread_create(&listener_tid, NULL, listener, NULL) != 0) {
        perror("Failed to create listener thread");

        sem_destroy(&sem_full);
        sem_destroy(&sem_empty);
        pthread_mutex_destroy(&lock);
        return 1;
    }


    for (int i = 0; i < numThread; i++) {
        int *worker_id = malloc(sizeof(int));
         if (worker_id == NULL) {
            perror("Failed to allocate memory for worker ID");

             continue;
         }
        *worker_id = i + 1;
        if (pthread_create(&worker_tids[i], NULL, worker, worker_id) != 0) {
            perror("Failed to create worker thread");
            free(worker_id);

            continue;
        }
    }



    pthread_join(listener_tid, NULL);


    for (int i = 0; i < numThread; i++) {
        pthread_join(worker_tids[i], NULL);
    }




    sem_destroy(&sem_full);
    sem_destroy(&sem_empty);
    pthread_mutex_destroy(&lock);


    printf("Server shutting down.\n");
    return 0;
}
